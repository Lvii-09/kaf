package in.krishak.agro.RMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
