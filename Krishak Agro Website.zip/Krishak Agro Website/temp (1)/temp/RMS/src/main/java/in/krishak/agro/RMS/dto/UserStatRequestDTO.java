package in.krishak.agro.RMS.dto;

import lombok.Data;

@Data
public class UserStatRequestDTO {
    private int limit;

    private int offset;
}
