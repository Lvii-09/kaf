package in.krishak.agro.RMS.service;

import in.krishak.agro.RMS.daos.CowDetailRepository;
import in.krishak.agro.RMS.models.CattleDetail;
import in.krishak.agro.RMS.models.User;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CattleService {

    @Autowired
    private CowDetailRepository cowDetailRepository;

    @Autowired
    private UserService userService;

    public void persistCowDetails(String userId, @Valid CattleDetail cattleDetail) throws Exception {
        try {
            User user = userService.fetchUserDetailByExternalId(userId);
            cattleDetail.setUserId(user.getId().toString());
            cowDetailRepository.save(cattleDetail);
        } catch (Exception e) {
            log.info("Error Persisting cow detail");
            throw new RuntimeException("Not able save cattle detail");
        }
    }
}
