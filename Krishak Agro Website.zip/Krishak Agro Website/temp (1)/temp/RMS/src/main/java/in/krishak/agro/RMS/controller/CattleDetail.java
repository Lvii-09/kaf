package in.krishak.agro.RMS.controller;

import in.krishak.agro.RMS.dto.UserInfo;
import in.krishak.agro.RMS.service.CattleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class CattleDetail {

    @Autowired
    private CattleService cattleService;

    @PostMapping("/info/cattle")
    public ResponseEntity<Void> fetchUserInfo(
            @RequestHeader("X-User-Id") String userId,
            @RequestBody in.krishak.agro.RMS.models.CattleDetail cattleDetail) throws Exception {
        cattleService.persistCowDetails(userId, cattleDetail);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
