package in.krishak.agro.RMS.daos;

import in.krishak.agro.RMS.models.CattleDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CowDetailRepository extends JpaRepository<CattleDetail, Long> {

}
